# Perfect Prairie — seven-post launch campaign

All artwork is 1080 × 1080 JPEG, ready for Instagram or Facebook. Suggested publishing order follows the filenames.

## Captions

### 01 — Something alive

What if a piece of your lawn could become food, shelter, color, and movement? Perfect Prairie creates thoughtful prairie, wildflower, and pollinator plots for homes and landowners in Central Illinois.

Learn more at perfectprairie.com

#PerfectPrairie #IllinoisPrairie #NativePlants #CentralIllinois

### 02 — Less lawn, more habitat

Less mowing. More blooms. More bees, butterflies, birds, and life. A prairie plot can turn an underused part of your property into something beautiful and useful.

Request a free estimate at perfectprairie.com

#LessLawn #MoreHabitat #PrairieGarden #IllinoisLandscapes

### 03 — Plant for pollinators

Pollinators need more than a moment of color. They need nectar, shelter, and connected habitat across the seasons. We design plots that make room for the small lives that keep everything else moving.

#PollinatorGarden #MonarchButterfly #NativeFlowers #PerfectPrairie

### 04 — Wild by nature

A prairie can look spontaneous and still be deeply intentional. The right species, site preparation, timing, and patient establishment create a landscape that belongs where it is planted.

#PrairieDesign #NativeLandscape #WildflowerMeadow #CentralIllinois

### 05 — Year after year

Prairie plants spend their early seasons building deep roots. Once established, they return year after year with less routine watering, no routine fertilizer, and more life in every season.

#DeepRoots #LowMaintenanceLandscape #PrairiePlants #PerfectPrairie

### 06 — A long memory

In 1820, prairie covered roughly 22 million acres of Illinois. By 1978, fewer than 2,300 acres of high-quality prairie remained. Every new patch is small—but it is also a meaningful return.

Archive image: *The Prairie Spirit in Landscape Gardening*, University of Illinois, 1915. Source: Cornell University Library / Internet Archive; no known copyright restrictions.

#PrairieState #IllinoisHistory #PrairieRestoration #NativeHabitat

### 07 — Start here

Have an open patch of lawn, field edge, or unused ground? Tell us about the site and what you want it to become. We’ll help shape the right prairie, wildflower, or pollinator plot for the land.

Request a free estimate at perfectprairie.com

#PerfectPrairie #CentralIllinoisBusiness #NativeLandscaping #StartAProject

## Source notes

- Post 04 uses “Illinois wildflowers” by American Lotus, CC BY-SA 4.0, via Wikimedia Commons.
- Post 06 uses a 1915 University of Illinois plate digitized by Cornell University Library / Internet Archive; no known copyright restrictions.
- Post 07 uses Carol M. Highsmith’s 2019 view near Galena from the Library of Congress; no known restrictions on publication.
- Posts 02 and 03 use AI-generated photographic backgrounds made for this campaign; typography and claims are deterministic overlays.
